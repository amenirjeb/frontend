import React from 'react';
import { Container, Form, Input, Label, Media, Row, Col } from 'reactstrap';
import CommonLayout from '../../components/shop/common-layout';
import aboutus from '../../public/assets/images/about/about-us.jpg';
import blog1 from '../../public/assets/images/blog/1.jpg';
import blog2 from '../../public/assets/images/blog/2.jpg';
import avtar from '../../public/assets/images/avtar.jpg';
import two from '../../public/assets/images/2.jpg';
import twenty from '../../public/assets/images/20.jpg';

const BlogDetail = () => {
    return (
        <CommonLayout parent="home" title="blog" subTitle="blogs">
            <section className="blog-detail-page section-b-space ratio2_3">
                <Container>
                    <Row>
                        <Col sm="12" className="blog">
                            <img src={'/assets/images/about/about-us.jpg'} className="img-fluid blur-up lazyload" alt="" />
                            <h3>Rencontres avec les artisans</h3>
                            <ul className="post-social">
                                <li>25 avril 2023</li>
                                <li>Posted By : Admin</li>
                                <li><i className="fa fa-heart"></i> 5 Hits</li>
                                <li><i className="fa fa-comments"></i> 10 Comment</li>
                            </ul>
                            <p><h4>Titre : Interview avec le designer tunisien Amine Yaiche</h4>

                                <p>
                                    Introduction :
                                    "Amine Yaiche est un designer tunisien diplômé de l'ESSTED, reconnu pour son talent et sa créativité.
                                    Passionné par l'artisanat et les matériaux naturels, il a récemment lancé sa collection de luminaires en rotin, alliant design moderne et élégance intemporelle."
                                    Avec son travail novateur et sa passion pour l'artisanat tunisien, Amine Yaiche apporte une contribution précieuse à la scène du design en Tunisie.
                                </p>

                                <p>Questions et réponses :
                                    <p>
                                        <p> Pourquoi avez-vous choisi ce secteur de design ?</p>
                                        J’ai choisi de m’orienter vers ce secteur à cause des contraintes que l’on rencontre en tant que jeune designer : en fait, on ne dispose pas de moyens nécessaires à la réalisation de quelconque produit conçu vu que plusieurs procédés et matériaux ne sont pas disponibles ou même accessibles en Tunisie.
                                        Par contre, nous disposons d’un travail artisanal riche et diversifié aussi bien en techniques de réalisation qu’en matériaux, il fallait donc créer tout en s’adaptant au travail artisanal et essayer d’en tirer le meilleur parti.</p>
                                    <p><p>Comment voyez-vous A’déco dans quelques années ?</p>
                                        L’idéal serait que A’déco devienne un jour un vaste espace de création et d’exposition semblables à ceux dont disposent certains créateurs et artistes qui permettrait de collaborer entre designers tunisiens partager des connaissances et expériences afin de mettre en avant le design produit en Tunisie.</p>

                                </p>
                            </p>
                        </Col>
                    </Row>
                    <Row className="section-b-space blog-advance">
                        <Col lg="6">
                            <div><Media src={'/assets/images/blog/1.jpg'} className="img-fluid blur-up lazyload bg-img" alt="" /></div>
                        </Col>
                        <Col lg='6'>
                            <div><Media src={'/assets/images/blog/2.jpg'} className="img-fluid blur-up lazyload bg-img" alt="" /></div>
                        </Col>
                        <Col lg="6">
                            <ul>
                                <p><h4>La poterie design de Slim Gharbi</h4></p>
                                <p>Slim Gharbi, expert en poterie, excelle dans son travail. Ses créations allient harmonieusement les vases, les pots et les carrés de faïence.
                                    Chaque pièce est méticuleusement conçue et embellie de motifs colorés, qui se révèlent sous un vernis éclatant.
                                    La passion de Slim Gharbi pour la poterie est toujours aussi vive et se reflète dans chacune de ses réalisations.
                                    «La Poterie de Slim Gharbi est le fruit de la transmission de notre savoir familial de génération en génération.
                                    Je suis potier, comme l’étaient mon père et mon grand-père avant moi. Mon atelier est situé à Nabeul, une ville où la poterie est une spécialité depuis l’Antiquité.
                                    La poterie fait partie de notre patrimoine, et le savoir-faire du travail de la terre est un capital précieux qu’il est important de conserver et de transmettre».

                                </p>
                            </ul>
                        </Col>
                        <Col lg="6">
                            <p><h4>L’artisanat tunisien à l’honneur

                            </h4></p>
                            <p>Découvrez une sélection unique de luminaires et d'objets de décoration en fibres végétales de Gabès, en Halfa de Kasserine et en poterie primitive de Rouached. Ajoutez une touche naturelle et authentique à votre intérieur tout en soutenant les artisans locaux et en préservant les traditions artisanales tunisiennes.
                                Créez un espace qui reflète votre style et votre passion pour l'artisanat.</p>

                        </Col>
                    </Row>
                    <Row className="section-b-space">
                        <Col sm="12">
                            <ul className="comment-section">
                                <li>
                                    <div className="media"><Media src={'/assets/images/avtar.jpg'} alt="Generic placeholder image" />
                                        <div className="media-body">
                                            <h6>Ameni <span>( 12 May 2023 at 1:30AM )</span></h6>
                                            <p>Explorez ces tendances artisanales et laissez-vous inspirer par la créativité des artisans. Que vous souhaitiez embellir votre intérieur, mettre à jour votre garde-robe ou offrir un cadeau unique, les produits artisanaux vous offrent une multitude d'options. Parcourez notre marketplace pour découvrir une sélection soigneusement choisie de produits artisanaux tendance. N'hésitez pas à soutenir les artisans et à ajouter une touche artisanale à votre vie quotidienne !</p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div className="media"><Media src={'/assets/images/2.jpg'} alt="Generic placeholder image" />
                                        <div className="media-body">
                                            <h6>Lina <span>( 12 may 2023 at 8:30AM )</span></h6>
                                            <p>Découvrez les dernières tendances artisanales qui font sensation cette saison ! Dans cet article, nous vous présentons les styles, les motifs, les matériaux et les couleurs les plus en vogue dans le monde de l'artisanat. Que vous soyez passionné(e) de décoration intérieure, de mode ou à la recherche du cadeau parfait, ces tendances vous inspireront à coup sûr. Suivez le guide et plongez dans l'univers créatif des artisans.</p>
                                        </div>
                                    </div>
                                </li>

                            </ul>
                        </Col>
                    </Row>
                    <Row className="blog-contact">
                        <Col sm="12">
                            <h2>Leave Your Comment</h2>
                            <Form className="theme-form">
                                <Row>
                                    <Col md="12">
                                        <Label className="form-label" for="name">Name</Label>
                                        <Input type="text" className="form-control" id="name" placeholder="Enter Your name"
                                            required="" />
                                    </Col>
                                    <Col md="12">
                                        <Label className="form-label" for="email">Email</Label>
                                        <Input type="text" className="form-control" id="email" placeholder="Email" required="" />
                                    </Col>
                                    <Col md="12">
                                        <Label className="form-label" for="exampleFormControlTextarea1">Comment</Label>
                                        <textarea className="form-control" placeholder="Write Your Comment"
                                            id="exampleFormControlTextarea1" rows="6"></textarea>
                                    </Col>
                                    <Col md="12">
                                        <button className="btn btn-solid" type="submit">Post Comment</button>
                                    </Col>
                                </Row>
                            </Form>
                        </Col>
                    </Row>
                </Container>
            </section>
        </CommonLayout>
    )
}

export default BlogDetail;