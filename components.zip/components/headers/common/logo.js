import React from 'react';
import Link from 'next/link';

const LogoImage = ({ logo }) => {
    return (
        <Link href="/">
            <a>
                <img src={`/assets/images/icon/${logo ? logo : 'logo.png'}`} alt="" className="img-fluid" style={{ height: "50px", width: "100px" }} />
            </a>
        </Link>
    );
};

export default LogoImage;
