import React, { Fragment } from "react";
import { Row, Col, Media } from "reactstrap";
import fashion from "../../../public/assets/images/mega-menu/fashion.jpg";

const SideBar = () => {
  const closeNav = () => {
    var closemyslide = document.getElementById("mySidenav");
    if (closemyslide) closemyslide.classList.remove("open-side");
  };

  const handleSubmenu = (event) => {
    if (event.target.classList.contains("sub-arrow")) {
      return;
    }

    if (event.target.nextElementSibling.classList.contains("opensub1"))
      event.target.nextElementSibling.classList.remove("opensub1");
    else {
      document.querySelectorAll(".opensub1").forEach(function (value) {
        value.classList.remove("opensub1");
      });
      event.target.nextElementSibling.classList.add("opensub1");
    }
  };

  const handleSubTwoMenu = (event) => {
    if (event.target.classList.contains("sub-arrow")) return;

    if (event.target.nextElementSibling.classList.contains("opensub2"))
      event.target.nextElementSibling.classList.remove("opensub2");
    else {
      document.querySelectorAll(".opensub2").forEach(function (value) {
        value.classList.remove("opensub2");
      });
      event.target.nextElementSibling.classList.add("opensub2");
    }
  };
  const handleSubThreeMenu = (event) => {
    if (event.target.classList.contains("sub-arrow")) return;

    if (event.target.nextElementSibling.classList.contains("opensub3"))
      event.target.nextElementSibling.classList.remove("opensub3");
    else {
      document.querySelectorAll(".opensub3").forEach(function (value) {
        value.classList.remove("opensub3");
      });
      event.target.nextElementSibling.classList.add("opensub3");
    }
  };

  const handleSubFourMenu = (event) => {
    if (event.target.classList.contains("sub-arrow")) return;

    if (event.target.nextElementSibling.classList.contains("opensub4"))
      event.target.nextElementSibling.classList.remove("opensub4");
    else {
      document.querySelectorAll(".opensub4").forEach(function (value) {
        value.classList.remove("opensub4");
      });
      event.target.nextElementSibling.classList.add("opensub4");
    }
  };

  const handleMegaSubmenu = (event) => {
    if (event.target.classList.contains("sub-arrow")) return;

    if (event.target.nextElementSibling.classList.contains("opensidesubmenu"))
      event.target.nextElementSibling.classList.remove("opensidesubmenu");
    else {
      event.target.nextElementSibling.classList.add("opensidesubmenu");
    }
  };

  return (
    <Fragment>
      <div id="mySidenav" className="sidenav">
        <a href={null} className="sidebar-overlay" onClick={closeNav}></a>
        <nav>
          <a href={null} onClick={closeNav}>
            <div className="sidebar-back text-start">
              <i className="fa fa-angle-left pe-2" aria-hidden="true"></i> Catégories
            </div>
          </a>
          <ul id="sub-menu" className="sidebar-menu">
            <li>
              <a href="#" onClick={(e) => handleMegaSubmenu(e)}>
                Vêtements
                <span className="sub-arrow"></span>
              </a>
              <ul className="mega-menu clothing-menu">
                <li>
                  <Row m="0">
                    <Col xl="4">
                      <div className="link-section">
                        <h5>Femme</h5>
                        <ul>
                          <li>
                            <a href="#">Jebba femme</a>
                          </li>
                          <li>
                            <a href="#">Robes</a>
                          </li>
                          <li>
                            <a href="#">fouta et blouse</a>
                          </li>
                          <li>
                            <a href="#">cafftan</a>
                          </li>
                          <li>
                            <a href="#">farmla</a>
                          </li>
                        </ul>
                        <h5>Homme</h5>
                        <ul>
                          <li>
                            <a href="#">Jebba homme </a>
                          </li>
                          <li>
                            <a href="#">costume traditionnel</a>
                          </li>
                          <li>
                            <a href="#">dengri</a>
                          </li>
                        </ul>
                      </div>
                    </Col>
                    <Col xl="4">
                      <div className="link-section">
                        <h5>Accessories</h5>
                        <ul>
                          <li>
                            <a href="#">Caps</a>
                          </li>
                          <li>
                            <a href="#">chechia</a>
                          </li>
                          <li>
                            <a href="#">ceintures</a>
                          </li>
                          <li>
                            <a href="#">port feuilles</a>
                          </li>
                          <li>
                            <a href="#">pochettes femme</a>
                          </li>
                        </ul>
                      </div>
                      <div className="link-section">
                        <h5>Chaussures</h5>
                        <ul>
                          <li>
                            <a href="#">Chaussures Femme</a>
                          </li>
                          <li>
                            <a href="#">Chaussures Homme</a>
                          </li>
                        </ul>
                      </div>
                    </Col>
                    <Col xl="4">
                      <a href="#" className="mega-menu-banner">
                        <Media src={fashion.src} alt="" className="img-fluid" />
                      </a>
                    </Col>
                  </Row>
                </li>
              </ul>
            </li>
            <li>
              <a href="#" onClick={(e) => handleSubmenu(e)}>
                Bijoux
                <span className="sub-arrow"></span>
              </a>
              <ul>
                <li>
                  <a href="#">Coliers</a>
                </li>
                <li>
                  <a href="#">Braclets</a>
                </li>
                <li>
                  <a href="#">Boucles</a>
                </li>
                <li>
                  <a href="#">Bagues</a>
                </li>
              </ul>
            </li>
            <li>
              <a href="#" onClick={(e) => handleSubmenu(e)}>
                Produits Bio
                <span className="sub-arrow"></span>
              </a>
              <ul className="mega-menu clothing-menu">
                <li>
                  <Row m="0">
                    <Col xl="4">
                      <div className="link-section">
                        <h5>cheveux</h5>
                        <ul>
                          <li>
                            <a href="#">shampo</a>
                          </li>
                          <li>
                            <a href="#">aprés shampo</a>
                          </li>
                          <li>
                            <a href="#">serum</a>
                          </li>
                          <li>
                            <a href="#">protein</a>
                          </li>
                        </ul>
                        <h5>corps</h5>
                        <ul>
                          <li>
                            <a href="#">gel douche</a>
                          </li>
                          <li>
                            <a href="#">lait de corps</a>
                          </li>
                          <li>
                            <a href="#">Baume</a>
                          </li>
                        </ul>
                      </div>
                    </Col>
                    <Col xl="4">
                      <div className="link-section">
                        <h5>Visages</h5>
                        <ul>
                          <li>
                            <a href="#">Ecran solaire</a>
                          </li>
                          <li>
                            <a href="#">créme hydratant</a>
                          </li>
                          <li>
                            <a href="#">serum</a>
                          </li>
                          <li>
                            <a href="#">Gel nettoyant</a>
                          </li>
                          <li>
                            <a href="#">Gommage</a>
                          </li>
                        </ul>
                      </div>
                      <div className="link-section">
                        <h5>beauté</h5>
                        <ul>
                          <li>
                            <a href="#">maquillage</a>
                          </li>
                        </ul>
                      </div>
                    </Col>
                  </Row>
                </li>
              </ul>
            </li>

            <li>
              <a href="#" onClick={(e) => handleSubmenu(e)}>
                Maison et Décoration
                <span className="sub-arrow"></span>
              </a>
              <ul>
                <li>
                  <a href="#">Tapis</a>
                </li>
                <li>
                  <a href="#">Margoum</a>
                </li>
                <li>
                  <a href="#">Art en Bois</a>
                </li>
                <li>
                  <a href="#">Tableaux</a>
                </li>
              </ul>
            </li>


          </ul>
        </nav>
      </div>
    </Fragment>
  );
};

export default SideBar;
