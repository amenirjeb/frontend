import React, { Fragment } from 'react';
import { Container, Row, Col, Media } from 'reactstrap';

const CopyRight = ({ layout, fluid }) => {
    return (
        <Fragment>
            <div className={`sub-footer ${layout}`}>
                <Container fluid={fluid}>
                    <Row>
                        <Col xl="6" md="6" sm="12">
                            <div className="MasterFooterend">
                                <p ><i className="fa fa-copyright" aria-hidden="true" ></i> 2023-24 mallart
                                    powered Artlyna</p>
                            </div>
                        </Col>

                    </Row>
                </Container>
            </div>
        </Fragment>
    )
}

export default CopyRight;